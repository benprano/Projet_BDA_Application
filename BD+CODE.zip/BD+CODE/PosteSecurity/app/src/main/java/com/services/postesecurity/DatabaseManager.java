package com.services.postesecurity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.Date;

public class DatabaseManager extends SQLiteOpenHelper {

    private static final String DB_NAME = "Service.db";
    private static final int DB_VERSION = 2;

    public DatabaseManager(Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String strSql = "CREATE TABLE T_Score (" +
                " idScore integer primary key autoincrement, " +
                " name text not null, " +
                " score integer not null, " +
                " when_ integer not null" +
                ");";
        sqLiteDatabase.execSQL(strSql);
        Log.i("DATABASE", "onCreate invoked");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        this.onCreate(sqLiteDatabase);

    }
    public void insertScore(String name, int score){

        name = name.replace("'", "''");

        String strSql = "INSERT INTO T_Score(name, score, when_) " +
                " VALUES('" + name + "', " + score + ", " + new Date().getTime() + ")";

        this.getWritableDatabase().execSQL(strSql);
        Log.i("DATABASE", "onInsertScore invoked");
    }
    public ArrayList<String> getUniversity(){

        ArrayList<String> university = new ArrayList<>();

        String strSql = "SELECT DISTINCT id, university FROM poste WHERE university != '' GROUP BY university ORDER BY university ASC";

        Cursor cursor =  this.getReadableDatabase().rawQuery(strSql, null);

        cursor.moveToFirst();

        while (! cursor.isAfterLast()){

            String element = new String(cursor.getString(1));

            university.add(element);
            cursor.moveToNext();
        }
        cursor.close();

        return university;
    }
    public ArrayList<LatLng> getPosteForUniversity(String _university){

        ArrayList<LatLng> latlongPoste = new ArrayList<LatLng>();

        String strSql = "SELECT latitude, longitude FROM poste WHERE university = '" + _university + "'";

        Cursor cursor = this.getReadableDatabase().rawQuery(strSql, null);

        cursor.moveToFirst();

        while (! cursor.isAfterLast()){

            double latitude = cursor.getDouble(0);
            double longitude = cursor.getDouble(1);

            latlongPoste.add(new LatLng(latitude, longitude));

            cursor.moveToNext();
        }
        cursor.close();

        return latlongPoste;
    }

}
