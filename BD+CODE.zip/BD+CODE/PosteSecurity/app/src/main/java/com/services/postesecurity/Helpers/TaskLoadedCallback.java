package com.services.postesecurity.Helpers;

public interface TaskLoadedCallback {
    void onTaskDone(Object...values);
}
